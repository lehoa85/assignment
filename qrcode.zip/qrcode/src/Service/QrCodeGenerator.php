<?php

namespace Drupal\qrcode\Service;

use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevelHigh;
use Endroid\QrCode\RoundBlockSizeMode\RoundBlockSizeModeMargin;
use Endroid\QrCode\Writer\PngWriter;

class QrCodeGenerator {
    /**
     * Generate QR code from given url and return path to QR code image
     * @url: URL with QR code contain
     * @name: name of QR code image generating
     */
    public function generateWithUrl(string $url, string $name): string {
        $publicUrl = "public://";
        $pathToQrCode = "";

        try {
            $result = Builder::create()
                        ->writer(new PngWriter())
                        ->writerOptions([])
                        ->data($url)
                        ->encoding(new Encoding('UTF-8'))
                        ->errorCorrectionLevel(new ErrorCorrectionLevelHigh())
                        ->size(300)
                        ->margin(10)
                        ->roundBlockSizeMode(new RoundBlockSizeModeMargin())
                        ->validateResult(false)
                        ->build();

            $qrCodeDirectory = \Drupal::service('file_system')->realpath($publicUrl);
            $result->saveToFile($qrCodeDirectory. "/" . $name);
            $pathToQrCode = file_create_url($publicUrl) . $name;
        } catch (\Exception $err) {
            \Drupal::logger('qrcode')->error($err);
        }
        return $pathToQrCode;
    }
}