<?php

namespace Drupal\qrcode\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\qrcode\Service\QrCodeGenerator;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides Qr code Block from given URL purchase link.
 *
 * @Block(
 *   id = "qr_code_purchase",
 *   admin_label = @Translation("QR code purchase"),
 *   category = @Translation("QR Code"),
 * )
 */
class QrCodePurchaseBlock extends BlockBase implements ContainerFactoryPluginInterface
{
  /**
   * @var QrCodeGenerator $qrCodeGenerator
   */
  protected $qrCodeGenerator;

  /**
   * @param array $configuration
   * @param string $plugin_id
   * @param mixed $plugin_definition
   * @param Drupal\qrcode\Service\QrCodeGenerator $qrCodeGenerator
   */
  public function __construct(array $configuration,
                              $plugin_id,
                              $plugin_definition,
                              QrCodeGenerator $qrCodeGenerator) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->qrCodeGenerator = $qrCodeGenerator;
  }

  /**
    * {@inheritdoc}
    */
  public static function create(ContainerInterface $container,
                                array $configuration,
                                $plugin_id,
                                $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('qrcode.generator')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    
    $product = \Drupal::routeMatch()->getParameter('node');
    $imageQrCode = self::generateQrCode($product);

    return [
      '#theme' => 'block_qrcode',
      '#qrcode_path' => $imageQrCode,
      '#attached' => [
        'library' => [
          'qrcode/product-css'
        ]
      ]
    ];
  }

   /**
   * @return int
   * Set no cache for this QR code block
   */
  public function getCacheMaxAge() {
    return 0;
  }

  /**
   * Generate QR code for given product
   */
  private function generateQrCode($product):string {
  
    if ($product instanceof \Drupal\node\NodeInterface) {
      $appPurchaseLink = $product->field_app_purchase_link->value;
      $qrCodeImageName = "qrcode-".$product->id().".png";
      return $this->qrCodeGenerator->generateWithUrl($appPurchaseLink, $qrCodeImageName);
    }
   
    return "";
  }
}